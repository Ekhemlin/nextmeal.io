import requests
import pymysql

def lambda_handler(event, context):   
    response = requests.get("https://google.com/")
    print(response.text)
    return response.text